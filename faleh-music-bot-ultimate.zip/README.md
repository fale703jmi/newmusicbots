
# Faleh Music Bot ULTIMATE (AR/EN, No Prefix, 24/7)

## الميزات
- عربي + إنجليزي بدون بريفكس
- 24/7 في روم صوتي ثابت + يمنع الأوامر خارج الروم
- تشغيل من روابط متعددة (YouTube/Spotify/SoundCloud/روابط مباشرة) + من **أسماء البحث**
- أوامر الأونر (أفتار/اسم/حالة)
- **ميزات مستخدمة بكثرة**: volume / loop / shuffle / seek / nowplaying / remove / jump / clear

## الأوامر
- شغل | play <رابط/بحث>
- تخطي | skip
- ايقاف | stop
- وقف | pause
- كمل | resume
- قائمة | queue
- اطلع | leave
- صوت | volume <0-200>   (الافتراضي 100)
- تكرار | loop <off/one/all>
- عشوائي | shuffle
- شيلة؟ | now | الان  (إظهار المقطع الحالي)
- شيل | remove <رقم>   (يحذف عنصر من الصف)
- اقفز | jump <رقم>     (يقفز لرقم في الصف)
- قدّم | seek <ثواني أو mm:ss>
- نظف | clear           (يمسح الصف)
- غيرافتار <رابط> | غيراسم <اسم> | غيرحالة <نص>  (Owner فقط)

## Env
TOKEN, OWNER_ID, GUILD_ID, FIXED_VC_ID

## Render
Build: npm install
Start: npm start
